import 'package:sqflite/sqflite.dart';
import 'database.dart';
import '../models/user_model.dart';

class UserRepository {
  static const String _table = "users";

  // ============================================================
  // ✅ تسجيل مستخدم جديد
  // ============================================================
  static Future<int> insertUser(AppUser user) async {
    final db = await AppDatabase.database;

    return await db.insert(
      _table,
      user.toJson(),
      conflictAlgorithm: ConflictAlgorithm.abort, // يمنع التكرار
    );
  }

  // ============================================================
  // ✅ التحقق إذا الـ username مستخدم مسبقًا
  // ============================================================
  static Future<bool> usernameExists(String username) async {
    final db = await AppDatabase.database;

    final res = await db.query(
      _table,
      where: "username = ?",
      whereArgs: [username],
    );

    return res.isNotEmpty; // true = موجود
  }

  // ============================================================
  // ✅ التحقق إذا الإيميل موجود مسبقًا
  // ============================================================
  static Future<bool> emailExists(String email) async {
    final db = await AppDatabase.database;

    final res = await db.query(_table, where: "email = ?", whereArgs: [email]);

    return res.isNotEmpty;
  }

  // ============================================================
  // ✅ تسجيل الدخول باستخدام (username أو email)
  // ============================================================
  static Future<AppUser?> loginByUserOrEmail({
    required String input,
    required String password,
  }) async {
    final db = await AppDatabase.database;

    final res = await db.query(
      _table,
      where: "(username = ? OR email = ?) AND password = ?",
      whereArgs: [input, input, password],
      limit: 1,
    );

    if (res.isEmpty) return null;

    return AppUser.fromJson(res.first);
  }

  // ============================================================
  // ✅ جلب مستخدم عبر ID
  // ============================================================
  static Future<AppUser?> getUserById(int? id) async {
    if (id == null) return null;

    final db = await AppDatabase.database;

    final res = await db.query(
      _table,
      where: "id = ?",
      whereArgs: [id],
      limit: 1,
    );

    if (res.isEmpty) return null;

    return AppUser.fromJson(res.first);
  }
}
