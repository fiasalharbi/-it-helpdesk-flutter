import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class AppDatabase {
  static Database? _db;

  // ============================================================
  // 🟣 فتح قاعدة البيانات (Singleton)
  // ============================================================
  static Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  // ============================================================
  // 🟣 تهيئة قاعدة البيانات
  // ============================================================
  static Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, "helpdesk.db");

    return await openDatabase(
      path,
      version: 3, // ← مهم جداً تغييره بعد التعديل
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  // ============================================================
  // 🟣 إنشاء الجداول لأول مرة
  // ============================================================
  static Future<void> _onCreate(Database db, int version) async {
    // جدول المستخدمين
    await db.execute("""
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullName TEXT NOT NULL,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role INTEGER NOT NULL
      );
    """);

    // جدول التذاكر
    await db.execute("""
      CREATE TABLE tickets (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        category INTEGER NOT NULL,
        priority INTEGER NOT NULL,
        status INTEGER NOT NULL,
        createdAt TEXT NOT NULL,
        updatedAt TEXT,
        createdBy INTEGER NOT NULL,
        assignedTo INTEGER,
        attachment TEXT,
        FOREIGN KEY (createdBy) REFERENCES users(id),
        FOREIGN KEY (assignedTo) REFERENCES users(id)
      );
    """);
  }

  // ============================================================
  // 🟣 ترقية قاعدة البيانات عند تغيير النسخة
  // ============================================================
  static Future<void> _onUpgrade(
    Database db,
    int oldVersion,
    int newVersion,
  ) async {
    // من الإصدار 1 إلى 2 أضفنا حقل attachment
    if (oldVersion < 2) {
      await db.execute("ALTER TABLE tickets ADD COLUMN attachment TEXT;");
    }

    // من الإصدار 2 إلى 3 أضفنا username UNIQUE
    if (oldVersion < 3) {
      await db.execute("ALTER TABLE users ADD COLUMN username TEXT;");
      await db.execute("CREATE UNIQUE INDEX idx_username ON users(username);");
    }
  }
}
