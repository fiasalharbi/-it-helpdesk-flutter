import 'package:sqflite/sqflite.dart';

import '../models/ticket.dart';
import 'database.dart';

class TicketsRepository {
  static const String _table = 'tickets';

  // ----------------------------------------------------
  // ✅ إضافة تذكرة جديدة
  // ----------------------------------------------------
  static Future<void> insertTicket(Ticket ticket) async {
    final db = await AppDatabase.database;

    await db.insert(
      _table,
      ticket.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ----------------------------------------------------
  // ✅ جلب جميع التذاكر (مرتّبة: الأحدث أولاً، ثم أعلى أولوية)
  // ----------------------------------------------------
  static Future<List<Ticket>> getAllTickets() async {
    final db = await AppDatabase.database;

    final rows = await db.query(_table);
    final list = rows.map((e) => Ticket.fromJson(e)).toList();

    // ترتيب: الأحدث أولاً، ثم أولوية أعلى (high > medium > low)
    list.sort((a, b) {
      final dateCmp = b.createdAt.compareTo(a.createdAt);
      if (dateCmp != 0) return dateCmp;
      return b.priority.index.compareTo(a.priority.index);
    });

    return list;
  }

  // ----------------------------------------------------
  // ✅ جلب تذكرة واحدة بـ ID (لو احتجتها)
  // ----------------------------------------------------
  static Future<Ticket?> getTicketById(String id) async {
    final db = await AppDatabase.database;

    final rows = await db.query(
      _table,
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );

    if (rows.isEmpty) return null;
    return Ticket.fromJson(rows.first);
  }

  // ----------------------------------------------------
  // ✅ تحديث تذكرة كاملة
  // ----------------------------------------------------
  static Future<void> updateTicket(Ticket ticket) async {
    final db = await AppDatabase.database;

    await db.update(
      _table,
      ticket.toJson(),
      where: 'id = ?',
      whereArgs: [ticket.id],
    );
  }

  // ----------------------------------------------------
  // ✅ حذف تذكرة
  // ----------------------------------------------------
  static Future<void> deleteTicket(String id) async {
    final db = await AppDatabase.database;

    await db.delete(_table, where: 'id = ?', whereArgs: [id]);
  }
}
