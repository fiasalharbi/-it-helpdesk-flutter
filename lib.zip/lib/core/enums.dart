/// ---------------------------------------------------------------------------
///  📁 enums.dart
///  هذا الملف يحتوي على جميع الـ Enums المستخدمة في التطبيق.
///  تصميمه يهدف إلى:
///   - تنظيم الكود وفصل الـ Domain Logic عن الـ UI.
///   - سهولة التوسع (إضافة حالة/نوع جديد بدون لمس الشاشات).
///   - توفير ترجمات عربية جاهزة للاستخدام في الواجهة.
/// ---------------------------------------------------------------------------

/// نوع المستخدم الذي قام بتسجيل الدخول.
/// - employee → موظف عادي يمكنه إنشاء تذاكر.
/// - it       → قسم تقنية المعلومات ويمكنه إدارة الحالات.
enum UserRole { employee, it }

/// تصنيف نوع المشكلة المقدمة في التذكرة.
/// يمكن التوسع لاحقًا بإضافة: (شبكة واي فاي، كاميرات، سيرفرات... إلخ)
enum TicketCategory {
  network, // مشاكل الشبكة
  printer, // مشاكل الطباعة
  device, // مشاكل أجهزة الكمبيوتر/الشاشات
  software, // مشاكل في البرامج أو الأنظمة
}

/// مستوى الأولوية للتذكرة.
/// مهم لإدارة الـ SLA داخل الشركات.
enum TicketPriority {
  high, // أولوية عالية – مشكلة تؤثر على العمل
  medium, // أولوية متوسطة – يمكن الانتظار
  low, // أولوية منخفضة – طلب تجميلي/تحسيني
}

/// حالة التذكرة داخل دورة حياتها.
/// تناسب Workflows الشركات.
enum TicketStatus {
  newTicket, // جديد – لم يتم التعامل معه بعد
  inProgress, // قيد التنفيذ – تم استلام البلاغ
  done, // مكتمل
}

/// ---------------------------------------------------------------------------
/// 📝 دوال مساعدة لتحويل الـ Enums إلى نصوص عربية تستخدم في الواجهة UI.
///  الهدف: فصل المنطق عن الواجهة Clean Architecture
/// ---------------------------------------------------------------------------

/// ترجمة نوع المشكلة (Category) إلى نص عربي.
String ticketCategoryToText(TicketCategory category) {
  switch (category) {
    case TicketCategory.network:
      return 'شبكة';
    case TicketCategory.printer:
      return 'طابعة';
    case TicketCategory.device:
      return 'جهاز';
    case TicketCategory.software:
      return 'برنامج';
  }
}

/// ترجمة الأولوية (Priority) إلى نص عربي.
String ticketPriorityToText(TicketPriority priority) {
  switch (priority) {
    case TicketPriority.high:
      return 'عالي';
    case TicketPriority.medium:
      return 'متوسط';
    case TicketPriority.low:
      return 'منخفض';
  }
}

/// ترجمة الحالة (Status) إلى نص عربي.
String ticketStatusToText(TicketStatus status) {
  switch (status) {
    case TicketStatus.newTicket:
      return 'جديد';
    case TicketStatus.inProgress:
      return 'قيد التنفيذ';
    case TicketStatus.done:
      return 'مكتمل';
  }
}
