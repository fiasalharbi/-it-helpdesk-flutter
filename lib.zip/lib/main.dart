import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'state/ticket_controller.dart';

// Screens
import 'screens/auth_wrapper.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/main_shell.dart';
import 'screens/tickets_list_screen.dart';
import 'screens/add_ticket_screen.dart';
import 'screens/ticket_details_screen.dart';
import 'screens/about_screen.dart';
import 'screens/profile_page.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const ITHelpdeskApp());
}

class ITHelpdeskApp extends StatelessWidget {
  const ITHelpdeskApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => TicketController(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'IT Helpdesk',

        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.lightTheme,
        themeMode: ThemeMode.light,

        // 👈 هذا المهم
        initialRoute: "/",

        routes: {
          "/": (_) => const AppWrapper(),

          SignUpScreen.routeName: (_) => const SignUpScreen(),
          MainShell.routeName: (_) => const MainShell(),
          TicketsListScreen.routeName: (_) => const TicketsListScreen(),
          AddTicketScreen.routeName: (_) => const AddTicketScreen(),
          TicketDetailsScreen.routeName: (_) => const TicketDetailsScreen(),
          AboutScreen.routeName: (_) => const AboutScreen(),
          ProfileScreen.routeName: (_) => const ProfileScreen(),
          DashboardScreen.routeName: (_) => const DashboardScreen(),
        },
      ),
    );
  }
}

class AppWrapper extends StatelessWidget {
  const AppWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();

    if (controller.currentUser == null) {
      return const LoginScreen();
    }

    return const MainShell();
  }
}

/// --------------------------------------------------
/// 🎨 App Theme
/// --------------------------------------------------
class AppTheme {
  AppTheme._();

  static const primaryPurple = Color(0xFF6246EA);
  static const bgColor = Color(0xFFF2EEFF);
  static const darkText = Color(0xFF1A1A1A);

  static ThemeData get lightTheme {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      fontFamily: 'SFPRO',
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryPurple,
        brightness: Brightness.light,
      ),
    );

    return base.copyWith(
      scaffoldBackgroundColor: bgColor,
      appBarTheme: const AppBarTheme(
        backgroundColor: primaryPurple,
        elevation: 0,
        centerTitle: true,
        foregroundColor: Colors.white,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }
}
