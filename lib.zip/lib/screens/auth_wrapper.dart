import 'package:flutter/material.dart';
import 'package:it_helpdesk/screens/login_screen.dart';
import 'package:it_helpdesk/screens/main_shell.dart';
import 'package:it_helpdesk/state/ticket_controller.dart';
import 'package:provider/provider.dart';

import 'package:it_helpdesk/state/ticket_controller.dart';
import 'package:it_helpdesk/screens/login_screen.dart';
import 'package:it_helpdesk/screens/main_shell.dart';

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();

    // لو مافي مستخدم → Login
    if (controller.currentUser == null) {
      return const LoginScreen();
    }

    // لو في مستخدم → MainShell
    return const MainShell();
  }
}
