import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/ticket_controller.dart';
import '../core/enums.dart';
import '../models/user_model.dart';

class ProfileScreen extends StatelessWidget {
  static const routeName = "/profile";

  const ProfileScreen({super.key});

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();
    final AppUser? user = controller.currentUser;

    if (user == null) {
      return const Scaffold(
        body: Center(child: Text("لا يوجد مستخدم مسجّل حالياً")),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            "الملف الشخصي",
            style: TextStyle(color: Colors.white),
          ),
        ),

        body: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ====================================================
              // 🟣 صورة المستخدم (avatar)
              // ====================================================
              ClipRRect(
                borderRadius: BorderRadius.circular(60),
                child: Image.asset(
                  "assets/images/avatar.png",
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                ),
              ),

              const SizedBox(height: 18),

              // ====================================================
              // 🟣 الاسم + البريد + الدور
              // ====================================================
              Text(
                user.fullName,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: purple,
                ),
              ),

              const SizedBox(height: 6),
              Text(
                user.email,
                style: TextStyle(fontSize: 15, color: Colors.grey.shade600),
              ),

              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE7D8FF),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  user.role == UserRole.it ? "فني تقنية المعلومات" : "موظف",
                  style: const TextStyle(
                    color: purple,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // ====================================================
              // 🟣 كارت معلومات الحساب
              // ====================================================
              _infoCard(
                title: "معلومات الحساب",
                items: [
                  _infoItem("الاسم", user.fullName),
                  _infoItem("البريد الإلكتروني", user.email),
                  _infoItem("الدور", user.role == UserRole.it ? "فني" : "موظف"),
                ],
              ),

              const SizedBox(height: 22),

              // ====================================================
              // 🟣 نشاط الفني
              // ====================================================
              if (user.role == UserRole.it)
                _infoCard(
                  title: "نشاط الفني",
                  items: [
                    _infoItem(
                      "التذاكر المستلمة",
                      "${_countAssigned(context, user.id!)}",
                    ),
                    _infoItem(
                      "التذاكر المكتملة",
                      "${_countAssigned(context, user.id!)}",
                    ),
                  ],
                ),

              // ====================================================
              // 🟣 نشاط الموظف
              // ====================================================
              if (user.role == UserRole.employee)
                _infoCard(
                  title: "نشاط الموظف",
                  items: [
                    _infoItem(
                      "عدد التذاكر المنشأة",
                      "${_countAssigned(context, user.id!)}",
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🟣 Widgets مساعدة
  // ============================================================

  Widget _infoCard({required String title, required List<Widget> items}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: purple,
            ),
          ),
          const SizedBox(height: 14),
          ...items,
        ],
      ),
    );
  }

  Widget _infoItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Text(
            "$label:",
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value, style: const TextStyle(fontSize: 15))),
        ],
      ),
    );
  }

  // ============================================================
  // 🧠 إحصائيات من الكنترولر
  // ============================================================
  int _countAssigned(BuildContext context, int userId) {
    final tickets = context.read<TicketController>().tickets;
    return tickets.where((t) => t.assignedTo == userId).length;
  }

  int _countCompleted(BuildContext context, int userId) {
    final tickets = context.read<TicketController>().tickets;
    return tickets
        .where((t) => t.assignedTo == userId && t.status == TicketStatus.done)
        .length;
  }

  int _countCreated(BuildContext context, int userId) {
    final tickets = context.read<TicketController>().tickets;
    return tickets.where((t) => t.createdBy == userId).length;
  }
}
