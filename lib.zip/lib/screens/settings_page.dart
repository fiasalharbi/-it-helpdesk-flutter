import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/ticket_controller.dart';
import 'profile_page.dart';
import 'about_screen.dart';
import 'login_screen.dart';

class SettingsPage extends StatelessWidget {
  static const routeName = "/settings";

  const SettingsPage({super.key});

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();
    final user = controller.currentUser;

    // =====================================================
    // 🛑 حماية من الشاشة الحمراء بعد تسجيل خروج
    // =====================================================
    if (user == null) {
      Future.microtask(() {
        Navigator.pushNamedAndRemoveUntil(
          context,
          LoginScreen.routeName,
          (route) => false,
        );
      });

      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          title: const Text(
            "الإعدادات",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          foregroundColor: Colors.white,
        ),

        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            // -----------------------------------------------------
            // 👤 الهيدر مع الصورة والاسم
            // -----------------------------------------------------
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage('assets/images/avatar.png'),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user.fullName,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          user.email,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            // -----------------------------------------------------
            // 🔵 الملف الشخصي
            // -----------------------------------------------------
            _settingsTile(
              icon: Icons.person,
              title: "الملف الشخصي",
              subtitle: "عرض بيانات حسابك",
              onTap: () {
                Navigator.pushNamed(context, ProfileScreen.routeName);
              },
            ),

            const SizedBox(height: 10),

            // -----------------------------------------------------
            // 🔵 حول التطبيق
            // -----------------------------------------------------
            _settingsTile(
              icon: Icons.info_rounded,
              title: "حول التطبيق",
              subtitle: "معلومات عن النظام والإصدار",
              onTap: () {
                Navigator.pushNamed(context, AboutScreen.routeName);
              },
            ),

            const SizedBox(height: 10),

            // -----------------------------------------------------
            // 🔴 تسجيل الخروج
            // -----------------------------------------------------
            _settingsTile(
              icon: Icons.logout,
              title: "تسجيل الخروج",
              subtitle: "الخروج من الحساب الحالي",
              isLogout: true,
              onTap: () => _logout(context),
            ),
          ],
        ),
      ),
    );
  }

  // =====================================================
  // 🔵 بلاطة الإعدادات
  // =====================================================
  Widget _settingsTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          radius: 22,
          backgroundColor: isLogout
              ? Colors.red.withOpacity(0.15)
              : purple.withOpacity(0.15),
          child: Icon(icon, color: isLogout ? Colors.red : purple),
        ),
        title: Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.black54)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
      ),
    );
  }

  // =====================================================
  // 🔴 تسجيل خروج (بدون أخطاء)
  // =====================================================
  void _logout(BuildContext context) {
    final controller = context.read<TicketController>();

    controller.currentUser = null;
    controller.notifyListeners();

    Navigator.pushNamedAndRemoveUntil(context, "/", (route) => false);
  }
}
