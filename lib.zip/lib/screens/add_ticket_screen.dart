import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/enums.dart';
import '../models/ticket.dart';
import '../state/ticket_controller.dart';

class AddTicketScreen extends StatefulWidget {
  static const routeName = '/add-ticket';

  const AddTicketScreen({super.key});

  @override
  State<AddTicketScreen> createState() => _AddTicketScreenState();
}

class _AddTicketScreenState extends State<AddTicketScreen> {
  final _formKey = GlobalKey<FormState>();
  final titleCtrl = TextEditingController();
  final descCtrl = TextEditingController();

  TicketCategory? selectedCategory;
  TicketPriority? selectedPriority;

  File? pickedImage;

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  Future<void> pickAttachment() async {
    final ImagePicker picker = ImagePicker();
    final XFile? file = await picker.pickImage(source: ImageSource.gallery);

    if (file != null) {
      setState(() {
        pickedImage = File(file.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.read<TicketController>();
    final user = controller.currentUser!;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          title: const Text(
            "إنشاء طلب صيانة",
            style: TextStyle(
              color: Colors.white, // ← يخلي النص أبيض 100%
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          backgroundColor: purple,
          elevation: 0,
          iconTheme: const IconThemeData(
            color: Colors.white,
          ), // ← يخلي السهم/الرجوع أبيض
        ),

        body: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // ====================== عنوان ======================
                _inputField(
                  controller: titleCtrl,
                  label: "عنوان الطلب",
                  hint: "مثال: توقف الطابعة عن العمل",
                  maxLines: 1,
                ),

                const SizedBox(height: 18),

                // ====================== وصف ======================
                _inputField(
                  controller: descCtrl,
                  label: "وصف المشكلة",
                  hint: "اشرح المشكلة بشكل واضح...",
                  maxLines: 4,
                ),

                const SizedBox(height: 20),

                // ====================== Dropdowns ======================
                _dropdownCategory(),
                const SizedBox(height: 16),
                _dropdownPriority(),

                const SizedBox(height: 20),

                // ====================== إضافة صورة ======================
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    "إرفاق صورة (اختياري)",
                    style: TextStyle(fontSize: 15, color: Colors.grey.shade700),
                  ),
                ),
                const SizedBox(height: 8),

                GestureDetector(
                  onTap: pickAttachment,
                  child: Container(
                    height: 130,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.purple.shade100),
                    ),
                    child: pickedImage == null
                        ? const Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.add_a_photo,
                                  size: 40,
                                  color: purple,
                                ),
                                SizedBox(height: 8),
                                Text("اضغط لإضافة صورة"),
                              ],
                            ),
                          )
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.file(
                              pickedImage!,
                              width: double.infinity,
                              height: 130,
                              fit: BoxFit.cover,
                            ),
                          ),
                  ),
                ),

                const SizedBox(height: 30),

                // ====================== زر الإرسال ======================
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: purple,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    child: const Text(
                      "إرسال الطلب",
                      style: TextStyle(fontSize: 17),
                    ),
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;

                      if (selectedCategory == null ||
                          selectedPriority == null) {
                        _snack("⚠ يرجى اختيار نوع المشكلة والأولوية");
                        return;
                      }

                      final ticket = Ticket(
                        id: DateTime.now().millisecondsSinceEpoch.toString(),
                        title: titleCtrl.text.trim(),
                        description: descCtrl.text.trim(),
                        category: selectedCategory!,
                        priority: selectedPriority!,
                        status: TicketStatus.newTicket,
                        createdAt: DateTime.now(),
                        updatedAt: null,
                        createdBy: user.id!,
                        assignedTo: null,
                        attachment: pickedImage?.path,
                      );

                      await controller.addTicket(ticket);

                      _snack("✔ تم إنشاء الطلب بنجاح");
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required int maxLines,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      validator: (v) =>
          (v == null || v.trim().isEmpty) ? "هذا الحقل مطلوب" : null,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        floatingLabelStyle: const TextStyle(color: purple),
        labelStyle: const TextStyle(color: purple),
        hintStyle: const TextStyle(color: Colors.black54),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.purple.shade100),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.purple.shade200),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(18)),
          borderSide: BorderSide(color: purple, width: 2),
        ),
      ),
    );
  }

  Widget _dropdownCategory() {
    return DropdownButtonFormField<TicketCategory>(
      decoration: _dropdownStyle("نوع المشكلة"),
      items: TicketCategory.values
          .map((c) => DropdownMenuItem(value: c, child: Text(_catLabel(c))))
          .toList(),
      onChanged: (v) => setState(() => selectedCategory = v),
      validator: (v) => v == null ? "مطلوب" : null,
    );
  }

  Widget _dropdownPriority() {
    return DropdownButtonFormField<TicketPriority>(
      decoration: _dropdownStyle("الأولوية"),
      items: TicketPriority.values
          .map(
            (p) => DropdownMenuItem(value: p, child: Text(_priorityLabel(p))),
          )
          .toList(),
      onChanged: (v) => setState(() => selectedPriority = v),
      validator: (v) => v == null ? "مطلوب" : null,
    );
  }

  InputDecoration _dropdownStyle(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: purple),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: Colors.purple.shade200),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: Colors.purple.shade200),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(18)),
        borderSide: BorderSide(color: purple, width: 2),
      ),
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  String _catLabel(TicketCategory c) {
    switch (c) {
      case TicketCategory.network:
        return "شبكة";
      case TicketCategory.printer:
        return "طابعة";
      case TicketCategory.device:
        return "جهاز";
      default:
        return "برنامج";
    }
  }

  String _priorityLabel(TicketPriority p) {
    switch (p) {
      case TicketPriority.low:
        return "منخفضة";
      case TicketPriority.medium:
        return "متوسطة";
      case TicketPriority.high:
        return "عالية";
    }
  }
}
