import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  static const routeName = '/about';

  const AboutScreen({super.key});

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF4F3FF);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,

        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          title: const Text(
            "عن التطبيق",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          foregroundColor: Colors.white,
        ),

        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 10),

            // ---------------- Header ----------------
            Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: purple.withOpacity(0.15),
                  ),
                  child: const Icon(
                    Icons.info_outline_rounded,
                    size: 60,
                    color: purple,
                  ),
                ),

                const SizedBox(height: 16),

                const Text(
                  "نظام الدعم الفني",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: purple,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  "إدارة تذاكر الصيانة والدعم الفني",
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // ---------------- عن النظام ----------------
            _section(
              title: "عن النظام",
              children: [
                Text(
                  "تم تطوير هذا النظام بهدف تنظيم وإدارة طلبات الصيانة "
                  "داخل المؤسسة، وتحسين كفاءة فريق الدعم الفني وتسريع "
                  "عملية حل المشكلات.",
                  style: TextStyle(
                    fontSize: 15,
                    height: 1.7,
                    color: Colors.grey.shade800,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // ---------------- معلومات التطبيق ----------------
            _section(
              title: "معلومات التطبيق",
              children: [
                _infoRow("اسم التطبيق", "IT Helpdesk Manager"),
                _infoRow("الإصدار", "1.0.0"),
                _infoRow("سنة الإصدار", "2025"),
              ],
            ),

            const SizedBox(height: 40),

            // ---------------- حقوق ----------------
            Center(
              child: Text(
                "© 2025 جميع الحقوق محفوظة",
                style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --------------------------------------------------------------------
  // 🟣 Section Container
  // --------------------------------------------------------------------
  Widget _section({required String title, required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: purple,
            ),
          ),
          const SizedBox(height: 14),
          ...children,
        ],
      ),
    );
  }

  // --------------------------------------------------------------------
  // 🟦 info row
  // --------------------------------------------------------------------
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Text(
            "$label:",
            style: const TextStyle(
              fontSize: 15,
              color: purple,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 15, color: Colors.grey.shade800),
            ),
          ),
        ],
      ),
    );
  }
}
