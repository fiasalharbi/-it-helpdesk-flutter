import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/enums.dart';
import '../state/ticket_controller.dart';

import 'tickets_list_screen.dart';
import 'settings_page.dart';
import 'add_ticket_screen.dart';
import 'dashboard_screen.dart';

class MainShell extends StatefulWidget {
  static const routeName = "/main-shell";

  // 🔥 متغير عام لحفظ آخر تبويب
  static int savedIndex = 0;

  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  bool _initialFixed = false;

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // 🔥 إصلاح المؤشر أول ما يدخل المستخدم بعد تسجيل الدخول
    if (!_initialFixed) {
      final controller = context.read<TicketController>();
      final user = controller.currentUser;

      final isIT = user?.role == UserRole.it;

      // عدد الصفحات حسب الدور
      final maxIndex = isIT ? 2 : 1;

      // لو savedIndex أكبر من الحد → رجعه 0
      if (MainShell.savedIndex > maxIndex) {
        MainShell.savedIndex = 0;
      }

      _currentIndex = MainShell.savedIndex;
      _initialFixed = true;

      // أول تحميل للتذاكر
      controller.loadTickets();
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();
    final user = controller.currentUser;
    final bool isIT = user?.role == UserRole.it;

    final pages = isIT
        ? const [DashboardScreen(), TicketsListScreen(), SettingsPage()]
        : const [TicketsListScreen(), SettingsPage()];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        body: IndexedStack(index: _currentIndex, children: pages),

        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: isIT
            ? null
            : FloatingActionButton(
                backgroundColor: purple,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddTicketScreen()),
                  );
                },
                child: const Icon(Icons.add, color: Colors.white),
              ),

        bottomNavigationBar: BottomAppBar(
          color: Colors.white,
          elevation: 10,
          shape: const CircularNotchedRectangle(),
          notchMargin: 10,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: isIT ? _itBar() : _employeeBar(),
          ),
        ),
      ),
    );
  }

  //========== تغيير الصفحة ==========
  void _switch(int i) {
    setState(() {
      _currentIndex = i;
      MainShell.savedIndex = i;
    });
  }

  //========== شريط الموظف ==========
  Widget _employeeBar() {
    return Row(
      children: [
        Expanded(
          child: _BottomItem(
            icon: Icons.list_alt_rounded,
            label: "تذاكري",
            isActive: _currentIndex == 0,
            onTap: () => _switch(0),
          ),
        ),
        const SizedBox(width: 40),
        Expanded(
          child: _BottomItem(
            icon: Icons.settings_rounded,
            label: "الإعدادات",
            isActive: _currentIndex == 1,
            onTap: () => _switch(1),
          ),
        ),
      ],
    );
  }

  //========== شريط الفني ==========
  Widget _itBar() {
    return Row(
      children: [
        Expanded(
          child: _BottomItem(
            icon: Icons.dashboard_rounded,
            label: "الرئيسية",
            isActive: _currentIndex == 0,
            onTap: () => _switch(0),
          ),
        ),
        const SizedBox(width: 40),
        Expanded(
          child: _BottomItem(
            icon: Icons.list_alt_rounded,
            label: "التذاكر",
            isActive: _currentIndex == 1,
            onTap: () => _switch(1),
          ),
        ),
        Expanded(
          child: _BottomItem(
            icon: Icons.settings_rounded,
            label: "الإعدادات",
            isActive: _currentIndex == 2,
            onTap: () => _switch(2),
          ),
        ),
      ],
    );
  }
}

class _BottomItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _BottomItem({
    required this.icon,
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF4F46E5);

    final color = isActive ? purple : Colors.grey;

    return InkWell(
      onTap: onTap,
      child: SizedBox(
        height: 58,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color),
            Text(label, style: TextStyle(color: color)),
          ],
        ),
      ),
    );
  }
}
