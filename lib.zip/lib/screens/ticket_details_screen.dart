import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/ticket.dart';
import '../core/enums.dart';
import '../state/ticket_controller.dart';
import 'edit_ticket_screen.dart';

class TicketDetailsScreen extends StatefulWidget {
  static const routeName = "/ticket-details";

  const TicketDetailsScreen({super.key});

  @override
  State<TicketDetailsScreen> createState() => _TicketDetailsScreenState();
}

class _TicketDetailsScreenState extends State<TicketDetailsScreen> {
  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  @override
  Widget build(BuildContext context) {
    final ticketId = ModalRoute.of(context)!.settings.arguments as String;

    final controller = context.watch<TicketController>();
    final ticket = controller.getById(ticketId);
    final user = controller.currentUser;

    if (ticket == null) {
      return const Scaffold(body: Center(child: Text("التذكرة غير موجودة")));
    }

    final bool isEmployee = user?.role == UserRole.employee;
    final bool isIT = user?.role == UserRole.it;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          title: const Text(
            "تفاصيل التذكرة",
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          actions: [
            if (isEmployee)
              IconButton(
                icon: const Icon(Icons.edit, color: Colors.white),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => EditTicketScreen(ticket: ticket),
                    ),
                  );
                },
              ),

            if (isEmployee)
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () => _confirmDelete(context, ticket.id),
              ),
          ],
        ),

        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ---------------- عنوان ----------------
              Text(
                ticket.title,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: purple,
                ),
              ),

              const SizedBox(height: 15),

              _detail("الوصف", ticket.description),
              _detail("نوع المشكلة", _categoryLabel(ticket.category)),
              _detail("الأولوية", _priorityLabel(ticket.priority)),
              _detail("الحالة", _statusLabel(ticket.status)),
              _detail(
                "التاريخ",
                "${ticket.createdAt.year}-${ticket.createdAt.month}-${ticket.createdAt.day}",
              ),

              if (ticket.updatedAt != null)
                _detail(
                  "آخر تحديث",
                  "${ticket.updatedAt!.year}-${ticket.updatedAt!.month}-${ticket.updatedAt!.day}",
                ),

              const SizedBox(height: 20),

              // ---------------- المرفق ----------------
              if (ticket.attachment != null) ...[
                const Text(
                  "المرفق:",
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: purple,
                  ),
                ),
                const SizedBox(height: 10),

                GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) =>
                          Dialog(child: Image.file(File(ticket.attachment!))),
                    );
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      File(ticket.attachment!),
                      height: 180,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                const SizedBox(height: 20),
              ],

              // ---------------- أدوات الفني ----------------
              if (isIT) _itControls(controller, ticket),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 أدوات الفني
  // ============================================================
  Widget _itControls(TicketController controller, Ticket t) {
    final isAssigned = t.assignedTo != null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "إجراءات الفني:",
          style: TextStyle(
            color: purple,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 16),

        // زر إسناد التذكرة
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: purple),
            onPressed: () async {
              await controller.assignToCurrentUser(t.id);
              setState(() {}); // 🔥 تحديث الشاشة مباشرة

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("✔ تم إسناد التذكرة إليك")),
              );
            },
            child: Text(isAssigned ? "🎉 تم الإسناد" : "إسناد التذكرة لي"),
          ),
        ),

        const SizedBox(height: 16),

        // تغيير الحالة
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.orange),
            onPressed: () async {
              TicketStatus next = TicketStatus.inProgress;

              if (t.status == TicketStatus.inProgress) {
                next = TicketStatus.done;
              }

              await controller.updateStatus(t.id, next);
              setState(() {}); // 🔥 تحديث الشاشة
            },
            child: const Text("تغيير الحالة"),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🔴 تأكيد حذف
  // ============================================================
  void _confirmDelete(BuildContext context, String id) {
    final controller = context.read<TicketController>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("حذف التذكرة"),
        content: const Text("هل تريد بالتأكيد حذف هذه التذكرة؟"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("إلغاء"),
          ),
          TextButton(
            onPressed: () async {
              await controller.deleteTicket(id);
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: const Text("حذف", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // عناصر العرض
  // ============================================================
  Widget _detail(String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: purple,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 15)),
        ],
      ),
    );
  }

  String _categoryLabel(TicketCategory c) {
    switch (c) {
      case TicketCategory.network:
        return "شبكة";
      case TicketCategory.printer:
        return "طابعة";
      case TicketCategory.device:
        return "جهاز";
      case TicketCategory.software:
        return "برنامج";
    }
  }

  String _priorityLabel(TicketPriority p) {
    switch (p) {
      case TicketPriority.low:
        return "منخفضة";
      case TicketPriority.medium:
        return "متوسطة";
      case TicketPriority.high:
        return "مرتفعة";
    }
  }

  String _statusLabel(TicketStatus s) {
    switch (s) {
      case TicketStatus.newTicket:
        return "جديد";
      case TicketStatus.inProgress:
        return "قيد التنفيذ";
      case TicketStatus.done:
        return "مكتمل";
    }
  }
}
