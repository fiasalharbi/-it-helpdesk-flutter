import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/ticket_controller.dart';
import '../core/enums.dart';
import 'tickets_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  static const routeName = "/dashboard";

  const DashboardScreen({super.key});

  static const purple = Color(0xFF4F46E5);
  static const bg = Color(0xFFF3F1FF);

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();
    final user = controller.currentUser;
    final tickets = controller.tickets;

    if (user == null) {
      return const Scaffold(body: Center(child: Text("لا يوجد مستخدم")));
    }

    // ----------------- الإحصائيات العامة -----------------
    final newCount = tickets
        .where((t) => t.status == TicketStatus.newTicket)
        .length;
    final inProgressCount = tickets
        .where((t) => t.status == TicketStatus.inProgress)
        .length;
    final doneCount = tickets
        .where((t) => t.status == TicketStatus.done)
        .length;

    // ----------------- الفني -----------------
    final assignedToMe = tickets.where((t) => t.assignedTo == user.id).length;
    final completedByMe = tickets
        .where((t) => t.assignedTo == user.id && t.status == TicketStatus.done)
        .length;

    // ----------------- الموظف -----------------
    final createdByMe = tickets.where((t) => t.createdBy == user.id).length;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            "لوحة التحكم",
            style: TextStyle(color: Colors.white, fontSize: 19),
          ),
        ),

        body: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "مرحباً، ${user.fullName}",
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: purple,
                ),
              ),

              const SizedBox(height: 6),
              Text(
                user.role == UserRole.it ? "إحصائيات الفني" : "إحصائيات الموظف",
                style: const TextStyle(fontSize: 15, color: Colors.black54),
              ),

              const SizedBox(height: 28),

              // ---------------- البطاقات العامة ----------------
              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      title: "جديد",
                      value: newCount,
                      icon: Icons.fiber_new,
                      onTap: () => _goToFiltered(
                        context,
                        status: TicketStatus.newTicket,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: _statCard(
                      title: "قيد التنفيذ",
                      value: inProgressCount,
                      icon: Icons.autorenew,
                      onTap: () => _goToFiltered(
                        context,
                        status: TicketStatus.inProgress,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      title: "مكتمل",
                      value: doneCount,
                      icon: Icons.check_circle_outline,
                      onTap: () =>
                          _goToFiltered(context, status: TicketStatus.done),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 35),

              // ---------------- الفني ----------------
              if (user.role == UserRole.it) ...[
                const Text(
                  "نشاط الفني",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: purple,
                  ),
                ),

                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(
                      child: _statCard(
                        title: "التذاكر المستلمة",
                        value: assignedToMe,
                        icon: Icons.handyman,
                        onTap: () =>
                            _goToFiltered(context, assignedTo: user.id),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: _statCard(
                        title: "أنجزتها",
                        value: completedByMe,
                        icon: Icons.done_all,
                        onTap: () => _goToFiltered(
                          context,
                          assignedTo: user.id,
                          status: TicketStatus.done,
                        ),
                      ),
                    ),
                  ],
                ),
              ],

              // ---------------- الموظف ----------------
              if (user.role == UserRole.employee) ...[
                const Text(
                  "نشاط الموظف",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: purple,
                  ),
                ),

                const SizedBox(height: 16),

                _statCard(
                  title: "طلباتك",
                  value: createdByMe,
                  icon: Icons.list_alt,
                  onTap: () => _goToFiltered(context, createdBy: user.id),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // -------------------------------------------------------------
  // 🔵 كرت الإحصائيات
  // -------------------------------------------------------------
  Widget _statCard({
    required String title,
    required int value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE0DDF7)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: purple.withOpacity(0.12),
              child: Icon(icon, color: purple, size: 26),
            ),

            const SizedBox(height: 16),

            Text(
              "$value",
              style: const TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: purple,
              ),
            ),

            const SizedBox(height: 4),

            Text(
              title,
              style: const TextStyle(fontSize: 15, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  // -------------------------------------------------------------
  // 🔎 الانتقال لقائمة التذاكر بفلترة جاهزة
  // -------------------------------------------------------------
  void _goToFiltered(
    BuildContext context, {
    int? createdBy,
    int? assignedTo,
    TicketStatus? status,
  }) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TicketsListScreen(
          extraFilterCreatedBy: createdBy,
          extraFilterAssignedTo: assignedTo,
          extraFilterStatus: status,
        ),
      ),
    );
  }
}
