import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/ticket.dart';
import '../core/enums.dart';
import 'package:provider/provider.dart';
import '../state/ticket_controller.dart';

class EditTicketScreen extends StatefulWidget {
  final Ticket ticket;

  const EditTicketScreen({super.key, required this.ticket});

  @override
  State<EditTicketScreen> createState() => _EditTicketScreenState();
}

class _EditTicketScreenState extends State<EditTicketScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController titleCtrl;
  late TextEditingController descCtrl;

  TicketCategory? selectedCategory;
  TicketPriority? selectedPriority;

  String? newAttachmentPath;

  static const purple = Color(0xFF4F46E5);

  @override
  void initState() {
    super.initState();

    titleCtrl = TextEditingController(text: widget.ticket.title);
    descCtrl = TextEditingController(text: widget.ticket.description);

    selectedCategory = widget.ticket.category;
    selectedPriority = widget.ticket.priority;

    newAttachmentPath = widget.ticket.attachment;
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.read<TicketController>();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F1FF),
        appBar: AppBar(
          backgroundColor: purple,
          elevation: 0,
          title: const Text(
            "تعديل التذكرة",
            style: TextStyle(color: Colors.white),
          ),
        ),

        body: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // ============================
                // 🔵 العنوان
                // ============================
                _inputField(
                  controller: titleCtrl,
                  label: "عنوان التذكرة",
                  maxLines: 1,
                ),

                const SizedBox(height: 18),

                // ============================
                // 🔵 الوصف
                // ============================
                _inputField(
                  controller: descCtrl,
                  label: "وصف المشكلة",
                  maxLines: 4,
                ),

                const SizedBox(height: 20),

                // ============================
                // 🔵 Dropdowns
                // ============================
                _dropdownCategory(),
                const SizedBox(height: 18),
                _dropdownPriority(),

                const SizedBox(height: 25),

                // ============================
                // 🟣 الصورة (المرفقات)
                // ============================
                _imageSection(context),

                const SizedBox(height: 35),

                // ============================
                // ✔ زر الحفظ
                // ============================
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: purple,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () async {
                      if (!_formKey.currentState!.validate()) return;

                      final updated = widget.ticket.copyWith(
                        title: titleCtrl.text.trim(),
                        description: descCtrl.text.trim(),
                        category: selectedCategory,
                        priority: selectedPriority,
                        updatedAt: DateTime.now(),
                        attachment: newAttachmentPath,
                      );

                      await controller.updateTicket(updated);

                      Navigator.pop(context);
                    },
                    child: const Text(
                      "حفظ التعديلات",
                      style: TextStyle(fontSize: 17),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===========================================================
  // 🔹 UI: حقل نص
  // ===========================================================
  Widget _inputField({
    required TextEditingController controller,
    required String label,
    required int maxLines,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      validator: (v) =>
          v == null || v.trim().isEmpty ? "هذا الحقل مطلوب" : null,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: purple),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: Colors.purple.shade100),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: purple, width: 2),
        ),
      ),
    );
  }

  // ===========================================================
  // 🔹 Dropdown Category
  // ===========================================================
  Widget _dropdownCategory() {
    return DropdownButtonFormField<TicketCategory>(
      decoration: _dropdownStyle("نوع المشكلة"),
      value: selectedCategory,
      items: TicketCategory.values.map((c) {
        return DropdownMenuItem(value: c, child: Text(_catLabel(c)));
      }).toList(),
      onChanged: (v) => setState(() => selectedCategory = v),
      validator: (v) => v == null ? "مطلوب" : null,
    );
  }

  // ===========================================================
  // 🔹 Dropdown Priority
  // ===========================================================
  Widget _dropdownPriority() {
    return DropdownButtonFormField<TicketPriority>(
      decoration: _dropdownStyle("الأولوية"),
      value: selectedPriority,
      items: TicketPriority.values.map((p) {
        return DropdownMenuItem(value: p, child: Text(_priorityLabel(p)));
      }).toList(),
      onChanged: (v) => setState(() => selectedPriority = v),
      validator: (v) => v == null ? "مطلوب" : null,
    );
  }

  // ===========================================================
  // 🔹 Dropdown Style
  // ===========================================================
  InputDecoration _dropdownStyle(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: purple),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: Colors.purple.shade200),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
        borderSide: BorderSide(color: purple, width: 2),
      ),
    );
  }

  // ===========================================================
  // 🟣 قسم المرفق (رفع / عرض صورة)
  // ===========================================================
  Widget _imageSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "المرفق:",
          style: TextStyle(
            color: purple,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 10),

        if (newAttachmentPath != null)
          Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(newAttachmentPath!),
                  height: 160,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),

        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _pickImage(),
            icon: const Icon(Icons.camera_alt, color: purple),
            label: const Text("تغيير المرفق", style: TextStyle(color: purple)),
          ),
        ),
      ],
    );
  }

  // ===========================================================
  // 📸 اختيار صورة من المعرض
  // ===========================================================
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final img = await picker.pickImage(source: ImageSource.gallery);

    if (img != null) {
      setState(() => newAttachmentPath = img.path);
    }
  }

  // ===========================================================
  // 🔹 LABEL HELPERS
  // ===========================================================
  String _catLabel(TicketCategory c) {
    switch (c) {
      case TicketCategory.network:
        return "شبكة";
      case TicketCategory.printer:
        return "طابعة";
      case TicketCategory.device:
        return "جهاز";
      case TicketCategory.software:
        return "برنامج";
    }
  }

  String _priorityLabel(TicketPriority p) {
    switch (p) {
      case TicketPriority.low:
        return "منخفضة";
      case TicketPriority.medium:
        return "متوسطة";
      case TicketPriority.high:
        return "مرتفعة";
    }
  }
}
