import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/enums.dart';
import '../state/ticket_controller.dart';
import '../data/user_repository.dart';
import '../models/user_model.dart';
import 'login_screen.dart';
import 'main_shell.dart';

class SignUpScreen extends StatefulWidget {
  static const routeName = "/signup";

  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final fullNameCtrl = TextEditingController();
  final usernameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  UserRole? selectedRole;

  bool _obscure = true;
  bool _loading = false;

  static const purple = Color(0xFF4F46E5);

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: purple,
        content: Text(msg, textDirection: TextDirection.rtl),
      ),
    );
  }

  Future<void> _signUp() async {
    if (!_formKey.currentState!.validate()) return;

    if (selectedRole == null) {
      _showSnack("⚠ يرجى اختيار نوع المستخدم");
      return;
    }

    setState(() => _loading = true);

    // تحقق من username
    if (await UserRepository.usernameExists(usernameCtrl.text.trim())) {
      setState(() => _loading = false);
      _showSnack("⚠ اسم المستخدم مستخدم مسبقاً!");
      return;
    }

    // تحقق من email
    if (await UserRepository.emailExists(emailCtrl.text.trim())) {
      setState(() => _loading = false);
      _showSnack("⚠ البريد الإلكتروني مستخدم مسبقاً!");
      return;
    }

    // إنشاء المستخدم
    final user = AppUser(
      fullName: fullNameCtrl.text.trim(),
      username: usernameCtrl.text.trim(),
      email: emailCtrl.text.trim(),
      password: passCtrl.text.trim(),
      role: selectedRole!,
    );

    await UserRepository.insertUser(user);

    setState(() => _loading = false);

    _showSnack("✔ تم إنشاء الحساب بنجاح");

    Navigator.pushReplacementNamed(context, LoginScreen.routeName);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F1FF),

        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // ---------------- Logo ----------------
                  const Icon(Icons.person_add, color: purple, size: 90),
                  const SizedBox(height: 10),

                  const Text(
                    "إنشاء حساب",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: purple,
                    ),
                  ),

                  const SizedBox(height: 25),

                  // ---------------- Full Name ----------------
                  _input(
                    controller: fullNameCtrl,
                    label: "الاسم الكامل",
                    icon: Icons.badge,
                  ),
                  const SizedBox(height: 18),

                  // ---------------- Username ----------------
                  _input(
                    controller: usernameCtrl,
                    label: "اسم المستخدم",
                    icon: Icons.person,
                  ),
                  const SizedBox(height: 18),

                  // ---------------- Email ----------------
                  _input(
                    controller: emailCtrl,
                    label: "البريد الإلكتروني",
                    icon: Icons.email,
                  ),
                  const SizedBox(height: 18),

                  // ---------------- Password ----------------
                  TextFormField(
                    controller: passCtrl,
                    obscureText: _obscure,
                    decoration: InputDecoration(
                      labelText: "كلمة المرور",
                      prefixIcon: const Icon(Icons.lock, color: purple),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscure ? Icons.visibility : Icons.visibility_off,
                          color: purple,
                        ),
                        onPressed: () {
                          setState(() {
                            _obscure = !_obscure;
                          });
                        },
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    validator: (v) =>
                        v!.trim().isEmpty ? "هذا الحقل مطلوب" : null,
                  ),

                  const SizedBox(height: 25),

                  // ---------------- اختيار نوع المستخدم ----------------
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      "نوع المستخدم",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: purple,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Expanded(
                        child: _roleCard(
                          label: "موظف",
                          icon: Icons.person,
                          selected: selectedRole == UserRole.employee,
                          onTap: () {
                            setState(() {
                              selectedRole = UserRole.employee;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _roleCard(
                          label: "فني IT",
                          icon: Icons.engineering,
                          selected: selectedRole == UserRole.it,
                          onTap: () {
                            setState(() {
                              selectedRole = UserRole.it;
                            });
                          },
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  // ---------------- Sign Up Button ----------------
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: purple,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: _loading ? null : _signUp,
                      child: _loading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                              "إنشاء الحساب",
                              style: TextStyle(fontSize: 17),
                            ),
                    ),
                  ),

                  const SizedBox(height: 18),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("لديك حساب؟"),
                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const LoginScreen(),
                            ),
                          );
                        },
                        child: const Text(
                          "تسجيل الدخول",
                          style: TextStyle(color: purple),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------------- INPUT FIELD ----------------
  Widget _input({required controller, required label, required icon}) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: purple),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
      validator: (v) => v!.trim().isEmpty ? "هذا الحقل مطلوب" : null,
    );
  }

  // ---------------- ROLE CARD ----------------
  Widget _roleCard({
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: selected ? purple.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? purple : Colors.grey.shade300,
            width: selected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: selected ? purple : Colors.grey.shade600,
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: selected ? purple : Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
