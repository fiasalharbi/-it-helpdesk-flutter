import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/ticket_controller.dart';
import '../core/enums.dart';
import '../models/ticket.dart';
import '../data/user_repository.dart';

import 'ticket_details_screen.dart';

class TicketsListScreen extends StatefulWidget {
  static const routeName = "/tickets";

  const TicketsListScreen({
    super.key,
    int? extraFilterCreatedBy,
    int? extraFilterAssignedTo,
    TicketStatus? extraFilterStatus,
  });

  @override
  State<TicketsListScreen> createState() => _TicketsListScreenState();
}

class _TicketsListScreenState extends State<TicketsListScreen> {
  TicketCategory? categoryFilter;
  TicketStatus? statusFilter;

  bool _isInit = true;
  bool _loading = true;

  // ============================================================
  // 🔥 حل مشكلة اللودينق: نستخدم didChangeDependencies
  // ============================================================
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isInit) {
      context.read<TicketController>().loadTickets().then((_) {
        setState(() => _loading = false);
      });
      _isInit = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<TicketController>();
    final user = controller.currentUser;

    final tickets = controller.tickets;

    // ============================================================
    // 🔥 ترتيب التذاكر حسب الجديد أولاً
    // ============================================================
    final filtered = tickets.where((t) {
      if (categoryFilter != null && t.category != categoryFilter) return false;
      if (statusFilter != null && t.status != statusFilter) return false;
      return true;
    }).toList()..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F3FF),

        appBar: AppBar(
          backgroundColor: const Color(0xFF4F46E5),
          elevation: 0,
          title: const Text(
            "التذاكر",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
        ),

        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  const SizedBox(height: 10),
                  _buildFiltersUI(),
                  const SizedBox(height: 10),

                  Expanded(
                    child: filtered.isEmpty
                        ? const Center(child: Text("لا توجد تذاكر"))
                        : ListView.builder(
                            padding: const EdgeInsets.all(14),
                            itemCount: filtered.length,
                            itemBuilder: (_, i) => _ticketCard(
                              filtered[i],
                              isEmployee: user?.role == UserRole.employee,
                            ),
                          ),
                  ),
                ],
              ),
      ),
    );
  }

  // ============================================================
  // 🔵 قائمة الفلاتر
  // ============================================================
  Widget _buildFiltersUI() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          _filterBtn("الكل", categoryFilter == null, () {
            setState(() => categoryFilter = null);
          }),
          _filterBtn("شبكة", categoryFilter == TicketCategory.network, () {
            setState(() => categoryFilter = TicketCategory.network);
          }),
          _filterBtn("طابعة", categoryFilter == TicketCategory.printer, () {
            setState(() => categoryFilter = TicketCategory.printer);
          }),
          _filterBtn("جهاز", categoryFilter == TicketCategory.device, () {
            setState(() => categoryFilter = TicketCategory.device);
          }),
          _filterBtn("برنامج", categoryFilter == TicketCategory.software, () {
            setState(() => categoryFilter = TicketCategory.software);
          }),
        ],
      ),
    );
  }

  Widget _filterBtn(String label, bool active, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: active ? const Color(0xFF4F46E5) : Colors.white,
            borderRadius: BorderRadius.circular(25),
            border: Border.all(color: const Color(0xFF4F46E5), width: 1.2),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: active ? Colors.white : const Color(0xFF4F46E5),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🟣 بطاقة التذكرة
  // ============================================================
  Widget _ticketCard(Ticket ticket, {required bool isEmployee}) {
    return FutureBuilder(
      future: _loadNames(ticket),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox();

        final createdBy = snap.data!["createdBy"];
        final assignedTo = snap.data!["assignedTo"];

        return GestureDetector(
          onTap: () {
            Navigator.pushNamed(
              context,
              TicketDetailsScreen.routeName,
              arguments: ticket.id,
            );
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 🔵 العنوان + أولوية + زر حذف
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        ticket.title,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                    _priorityBadge(ticket.priority),

                    if (isEmployee)
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _confirmDelete(ticket.id),
                      ),
                  ],
                ),

                const SizedBox(height: 12),

                Row(
                  children: [
                    _categoryBadge(ticket.category),
                    const SizedBox(width: 10),
                    _statusBadge(ticket.status),
                  ],
                ),

                const SizedBox(height: 12),

                if (assignedTo != null)
                  _infoRow(Icons.engineering, "مستلم:", assignedTo),

                _infoRow(Icons.person, "منشأة بواسطة:", createdBy!),

                _infoRow(
                  Icons.access_time,
                  "آخر تحديث:",
                  _format(ticket.updatedAt ?? ticket.createdAt),
                ),

                if (ticket.attachment != null) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: const [
                      Icon(Icons.attachment, color: Colors.grey, size: 20),
                      SizedBox(width: 6),
                      Text("مرفق موجود"),
                    ],
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // 🔥 تأكيد الحذف
  // ============================================================
  void _confirmDelete(String id) {
    final controller = context.read<TicketController>();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("حذف التذكرة"),
        content: const Text("هل أنت متأكد من حذف هذه التذكرة؟"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("إلغاء"),
          ),
          TextButton(
            onPressed: () async {
              await controller.deleteTicket(id);
              Navigator.pop(ctx);
            },
            child: const Text("حذف", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🧠 تحميل أسماء المستخدمين
  // ============================================================
  Future<Map<String, String?>> _loadNames(Ticket t) async {
    final createdUser = await UserRepository.getUserById(t.createdBy);
    final assignedUser = t.assignedTo != null
        ? await UserRepository.getUserById(t.assignedTo!)
        : null;

    return {
      "createdBy": createdUser?.fullName ?? "غير معروف",
      "assignedTo": assignedUser?.fullName,
    };
  }

  // ============================================================
  // 🎨 Badges
  // ============================================================
  Widget _priorityBadge(TicketPriority p) {
    String text;
    Color color;

    switch (p) {
      case TicketPriority.high:
        text = "عالي";
        color = Colors.red.shade300;
        break;
      case TicketPriority.medium:
        text = "متوسط";
        color = Colors.orange.shade300;
        break;
      default:
        text = "منخفض";
        color = Colors.green.shade300;
    }
    return _badge(text, color);
  }

  Widget _statusBadge(TicketStatus s) {
    String text;
    Color color;

    switch (s) {
      case TicketStatus.newTicket:
        text = "جديد";
        color = Colors.grey.shade300;
        break;
      case TicketStatus.inProgress:
        text = "قيد التنفيذ";
        color = Colors.blue.shade200;
        break;
      default:
        text = "مكتمل";
        color = Colors.green.shade300;
    }
    return _badge(text, color);
  }

  Widget _categoryBadge(TicketCategory c) {
    String text;
    switch (c) {
      case TicketCategory.network:
        text = "شبكة";
        break;
      case TicketCategory.printer:
        text = "طابعة";
        break;
      case TicketCategory.device:
        text = "جهاز";
        break;
      default:
        text = "برنامج";
    }
    return _badge(text, const Color(0xFFE5D8FF));
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12)),
    );
  }

  // ============================================================
  // Row Helper
  // ============================================================
  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Icon(icon, size: 17, color: Colors.grey.shade600),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(width: 6),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  String _format(DateTime d) {
    final m = d.minute.toString().padLeft(2, '0');
    return "${d.year}-${d.month}-${d.day} / ${d.hour}:$m";
  }
}
