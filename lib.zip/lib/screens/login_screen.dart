import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/ticket_controller.dart';
import '../data/user_repository.dart';
import '../models/user_model.dart';
import 'main_shell.dart';
import 'signup_screen.dart';

class LoginScreen extends StatefulWidget {
  static const routeName = "/login";

  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final inputCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _obscure = true;
  bool _loading = false;

  static const purple = Color(0xFF4F46E5);

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: purple,
        content: Text(msg, textDirection: TextDirection.rtl),
      ),
    );
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    final user = await UserRepository.loginByUserOrEmail(
      input: inputCtrl.text.trim(),
      password: passCtrl.text.trim(),
    );

    setState(() => _loading = false);

    if (user == null) {
      _showSnack("❌ اسم المستخدم أو كلمة المرور غير صحيحة");
      return;
    }

    context.read<TicketController>().setUser(user);

    Navigator.pushReplacementNamed(context, MainShell.routeName);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F1FF),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              children: [
                // ------------------------------ Logo ------------------------------
                const Icon(
                  Icons.support_agent_rounded,
                  color: purple,
                  size: 90,
                ),
                const SizedBox(height: 10),

                const Text(
                  "مرحباً بك",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: purple,
                  ),
                ),

                const SizedBox(height: 30),

                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // ------------------------------ Username / Email ------------------------------
                      TextFormField(
                        controller: inputCtrl,
                        decoration: InputDecoration(
                          labelText: "اسم المستخدم أو الإيميل",
                          prefixIcon: const Icon(Icons.person, color: purple),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        validator: (v) =>
                            v!.trim().isEmpty ? "هذا الحقل مطلوب" : null,
                      ),

                      const SizedBox(height: 18),

                      // ------------------------------ Password ------------------------------
                      TextFormField(
                        controller: passCtrl,
                        obscureText: _obscure,
                        decoration: InputDecoration(
                          labelText: "كلمة المرور",
                          prefixIcon: const Icon(Icons.lock, color: purple),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscure
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: purple,
                            ),
                            onPressed: () {
                              setState(() {
                                _obscure = !_obscure;
                              });
                            },
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        validator: (v) =>
                            v!.trim().isEmpty ? "هذا الحقل مطلوب" : null,
                      ),

                      const SizedBox(height: 25),

                      // ------------------------------ Login Button ------------------------------
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          style: FilledButton.styleFrom(
                            backgroundColor: purple,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          onPressed: _loading ? null : _login,
                          child: _loading
                              ? const CircularProgressIndicator(
                                  color: Colors.white,
                                )
                              : const Text(
                                  "تسجيل الدخول",
                                  style: TextStyle(fontSize: 17),
                                ),
                        ),
                      ),

                      const SizedBox(height: 18),

                      // ------------------------------ Sign Up ------------------------------
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("ليس لديك حساب؟"),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                context,
                                SignUpScreen.routeName,
                              );
                            },
                            child: const Text(
                              "إنشاء حساب",
                              style: TextStyle(color: purple),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
