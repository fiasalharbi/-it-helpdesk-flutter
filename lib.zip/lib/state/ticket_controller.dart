import 'package:flutter/material.dart';

import '../models/ticket.dart';
import '../core/enums.dart';
import '../data/ticket_repository.dart';
import '../models/user_model.dart';

class TicketController extends ChangeNotifier {
  AppUser? currentUser;
  List<Ticket> tickets = [];

  // ---------------------------------------------------------
  // ✔ تعيين المستخدم الحالي
  // ---------------------------------------------------------
  // ---------------------------------------------------------
  // ✔ تعيين المستخدم الحالي (يسمح بـ null الآن)
  // ---------------------------------------------------------
  void setUser(AppUser? user) {
    currentUser = user;
    notifyListeners();
  }

  // ---------------------------------------------------------
  // ✔ تحميل وترتيب التذاكر
  // ---------------------------------------------------------
  Future<void> loadTickets() async {
    tickets = await TicketsRepository.getAllTickets();

    // 🔥 ترتيب التذاكر (الأحدث أول + الأولوية)
    tickets.sort((a, b) {
      // أولاً حسب الحالة
      int statusOrder(TicketStatus s) {
        switch (s) {
          case TicketStatus.inProgress:
            return 0; // الأهم
          case TicketStatus.newTicket:
            return 1;
          case TicketStatus.done:
            return 2;
        }
      }

      final statusCompare = statusOrder(
        a.status,
      ).compareTo(statusOrder(b.status));
      if (statusCompare != 0) return statusCompare;

      // ثانياً حسب الأولوية
      final priorityCompare = b.priority.index.compareTo(a.priority.index);
      if (priorityCompare != 0) return priorityCompare;

      // ثالثاً حسب الأحدث
      return b.createdAt.compareTo(a.createdAt);
    });

    notifyListeners();
  }

  // ---------------------------------------------------------
  // ✔ الحصول على تذكرة
  // ---------------------------------------------------------
  Ticket? getById(String id) {
    try {
      return tickets.firstWhere((t) => t.id == id);
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------
  // ✔ إضافة تذكرة
  // ---------------------------------------------------------
  Future<void> addTicket(Ticket ticket) async {
    await TicketsRepository.insertTicket(ticket);
    await loadTickets();
  }

  // ---------------------------------------------------------
  // ✔ تحديث تذكرة
  // ---------------------------------------------------------
  Future<void> updateTicket(Ticket updated) async {
    await TicketsRepository.updateTicket(updated);
    await loadTickets();
  }

  // ---------------------------------------------------------
  // ✔ حذف تذكرة
  // ---------------------------------------------------------
  Future<void> deleteTicket(String id) async {
    await TicketsRepository.deleteTicket(id);
    await loadTickets();
  }

  // ---------------------------------------------------------
  // ✔ تغيير حالة التذكرة (IT)
  // ---------------------------------------------------------
  Future<void> updateStatus(String id, TicketStatus newStatus) async {
    final ticket = getById(id);
    if (ticket == null) return;

    final updated = ticket.copyWith(
      status: newStatus,
      updatedAt: DateTime.now(),
    );

    await TicketsRepository.updateTicket(updated);
    await loadTickets();
  }

  // ---------------------------------------------------------
  // ✔ إسناد التذكرة للفني الحالي (IT)
  // ---------------------------------------------------------
  Future<void> assignToCurrentUser(String id) async {
    if (currentUser == null) return;

    final ticket = getById(id);
    if (ticket == null) return;

    final updated = ticket.copyWith(
      assignedTo: currentUser!.id,
      updatedAt: DateTime.now(),
    );

    await TicketsRepository.updateTicket(updated);
    await loadTickets();
  }

  // ---------------------------------------------------------
  // ✔ حفظ مرفق (صورة)
  // ---------------------------------------------------------
  Future<void> attachImage(String id, String path) async {
    final ticket = getById(id);
    if (ticket == null) return;

    final updated = ticket.copyWith(
      attachment: path,
      updatedAt: DateTime.now(),
    );

    await TicketsRepository.updateTicket(updated);
    await loadTickets();
  }
}
