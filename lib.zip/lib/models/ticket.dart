import '../core/enums.dart';

class Ticket {
  final String id;
  final String title;
  final String description;
  final TicketCategory category;
  final TicketPriority priority;
  TicketStatus status;
  final DateTime createdAt;
  DateTime? updatedAt;
  final int createdBy;
  int? assignedTo;
  String? attachment; // مسار الصورة

  Ticket({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.priority,
    required this.status,
    required this.createdAt,
    this.updatedAt,
    required this.createdBy,
    this.assignedTo,
    this.attachment,
  });

  // --------------------------------------------------------------------
  // 🟣 copyWith — مهم للتعديل على التذكرة
  // --------------------------------------------------------------------
  Ticket copyWith({
    String? id,
    String? title,
    String? description,
    TicketCategory? category,
    TicketPriority? priority,
    TicketStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    int? createdBy,
    int? assignedTo,
    String? attachment,
  }) {
    return Ticket(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      priority: priority ?? this.priority,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      createdBy: createdBy ?? this.createdBy,
      assignedTo: assignedTo ?? this.assignedTo,
      attachment: attachment ?? this.attachment,
    );
  }

  // --------------------------------------------------------------------
  // 🟣 JSON → Ticket
  // --------------------------------------------------------------------
  factory Ticket.fromJson(Map<String, dynamic> json) {
    return Ticket(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      category: TicketCategory.values[json['category']],
      priority: TicketPriority.values[json['priority']],
      status: TicketStatus.values[json['status']],
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'])
          : null,
      createdBy: json['createdBy'],
      assignedTo: json['assignedTo'],
      attachment: json['attachment'],
    );
  }

  // --------------------------------------------------------------------
  // 🟣 Ticket → JSON (لـ SQLite)
  // --------------------------------------------------------------------
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'category': category.index,
      'priority': priority.index,
      'status': status.index,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'createdBy': createdBy,
      'assignedTo': assignedTo,
      'attachment': attachment,
    };
  }
}
