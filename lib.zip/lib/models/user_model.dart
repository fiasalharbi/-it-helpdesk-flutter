import '../core/enums.dart';

class AppUser {
  final int? id;
  final String fullName;
  final String username; // 👈 اسم المستخدم الجديد
  final String email;
  final String password;
  final UserRole role;

  const AppUser({
    this.id,
    required this.fullName,
    required this.username,
    required this.email,
    required this.password,
    required this.role,
  });

  // ------------------------------------------------------
  // 🟣 Object → JSON (للـ SQLite)
  // ------------------------------------------------------
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'fullName': fullName,
      'username': username, // 👈 مضاف
      'email': email,
      'password': password,
      'role': role.index,
    };
  }

  // ------------------------------------------------------
  // 🟣 JSON → Object
  // ------------------------------------------------------
  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'] as int?,
      fullName: json['fullName'],
      username: json['username'] ?? "", // 👈 عشان لا يعطي Null
      email: json['email'],
      password: json['password'],
      role: UserRole.values[json['role']],
    );
  }
}
